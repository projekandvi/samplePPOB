package com.dian.ppob.model;

import com.google.gson.annotations.SerializedName;

public class TransaksiModel {


//    public String getCommand() {
//        return command;
//    }
//
//    public void setCommand(String command) {
//        this.command = command;
//    }
//
//    @SerializedName("command")
//    private String command;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @SerializedName("message")
    private String message;


}
