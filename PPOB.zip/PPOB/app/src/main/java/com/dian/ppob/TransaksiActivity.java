package com.dian.ppob;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.dian.ppob.model.TransaksiModel;
import com.dian.ppob.rest.Api;
import com.dian.ppob.rest.Apiinterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TransaksiActivity extends AppCompatActivity {
    Button btn_transaksi;
    EditText input_command,input_msisdn,input_pin,input_product_id,input_request_id,input_no_hp;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaksi);
        btn_transaksi=findViewById(R.id.btn_transaksi);
        input_command=findViewById(R.id.input_command);
        input_msisdn=findViewById(R.id.input_msisdn);
        input_pin=findViewById(R.id.input_pin);
        input_product_id=findViewById(R.id.input_product_id);
        input_request_id=findViewById(R.id.input_request_id);
        input_no_hp=findViewById(R.id.input_no_hp);
        progressBar=findViewById(R.id.progressBar);

        btn_transaksi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Trans();
            }
        });

    }

    private void Trans () {
        progressBar.setVisibility(View.VISIBLE);
        Apiinterface apiinterface = Api.getUrl().create(Apiinterface.class);
        Call<TransaksiModel> call =apiinterface.postTransaksi(input_command.getText().toString(),
                                                              input_msisdn.getText().toString(),
                                                              input_pin.getText().toString(),
                                                              input_product_id.getText().toString(),
                                                              input_request_id.getText().toString(),
                                                              input_no_hp.getText().toString());
        call.enqueue(new Callback<TransaksiModel>() {
            @Override
            public void onResponse(Call<TransaksiModel> call, Response<TransaksiModel> response) {
                if(response.body().getMessage().equals("transaksi sudah diterima dan akan segera diproses")) {
                    Intent intent = new Intent(TransaksiActivity.this, MainActivity.class);
                    startActivity(intent);
                }else {
                    Toast.makeText(getApplicationContext(),"Salah Input",Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                }
            }

            @Override
            public void onFailure(Call<TransaksiModel> call, Throwable t) {

            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        progressBar.setVisibility(View.GONE);

    }
}
