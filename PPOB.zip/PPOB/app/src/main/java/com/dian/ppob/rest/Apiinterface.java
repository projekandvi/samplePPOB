package com.dian.ppob.rest;


import com.dian.ppob.model.TransaksiModel;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface Apiinterface {

    @FormUrlEncoded
    @POST("transaksi")
    Call<TransaksiModel>  postTransaksi(@Field("command") String command,
                                         @Field("msisdn") String msisdn,
                                         @Field("pin") String pin ,
                                         @Field("product_id") String product_id,
                                         @Field("request_id") String request_id,
                                         @Field("no_hp") String no_hp
                                         );

}
